import './App.css';

import logo from './logo.svg';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Tienda Online | E-commerce.
        </p>
        <a
          className="App-link"
          href="https://mercadolibre.com.ar"
          target="_blank"
          rel="noopener noreferrer"
        >
          Visita el sitio
        </a>
      </header>
    </div>
  );
}

export default App;
